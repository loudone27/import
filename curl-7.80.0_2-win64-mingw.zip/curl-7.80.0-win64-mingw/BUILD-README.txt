Visit the project page for details about these builds and the list of changes:

   https://github.com/curl/curl-for-win
