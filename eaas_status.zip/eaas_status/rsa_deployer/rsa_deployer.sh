#!/bin/ksh
#========================================================================================#
#          -                                                                             #
# title           : rsa_deployer                                                         #
# description     :Activity Control Solr/zookeeper/kafka/file_system/rest_api            #
# author          :Hertzog Ludovic & Tavarich                                            #
# date            :16/11/2017                                                            #
# version         :1.0                                                                   #
# notes           :Please advise Exparc team if you encounter any problem                #
#========================================================================================#

#------------------------------------------------
# USER DEFINITION
#------------------------------------------------

REP_PROG=$(dirname $0)
PROG=$(basename $0)
USER=$(whoami)
HOST=$(hostname)

LOG_DATE=`date +"%b-%d-%y"`

#------------------------------------------------
# COLORS DEFINITION
#------------------------------------------------

ROUGE="\\033[1;31m"         
ROUGE_SOU="\033[04;01;31m"  
ROUGE_SUR="\\033[41;38m"    
JAUNE="\\033[1;33m"         
JAUNE_SOU="\\033[04;01;33m" 
JAUNE_SUR="\\033[43;30m"    
VIOLET="\\033[1;35m"        
VERT="\\033[1;32m"          
VERT_SOU="\\033[04;01;32m"  
VERT_SUR="\\033[42;30m"     
CYAN="\\033[1;36m"          
NORMAL="\\033[0;39m"        
BLACK_SOU="\\033[04;01;30m" 
WHITE_SUR="\\033[47;30m"    
BLUE="\\033[1;34m"          

#------------------------------------------------
# PATH KEYGEN LOCATION
#------------------------------------------------

REP_RSA="/home/${USER}/.ssh"

#------------------------------------------------
# HIDDING PASSWORD FUNCTION
#------------------------------------------------

f_read_secret()
{
    # Disable echo.
    stty -echo

    # Set up trap to ensure echo is enabled before exiting if the script
    # is terminated while echo is disabled.
    trap 'stty echo' EXIT

    # Read secret.
    read "$@"

    # Enable echo.
    stty echo
    trap - EXIT

    # Print a newline because the newline entered by the user after
    # entering the passcode is not echoed. This ensures that the
    # next line of output begins at a new line.
    echo
}


#------------------------------------------------
# SECTION PASSWORD ENTER BY USER IN PROMPT
#------------------------------------------------

echo "What is your password?: "

f_read_secret PWD

if [ -z "$PWD" ]; then
echo -e "${JAUNE}You're password is empty exiting program...${NORMAL}"
exit 0
fi


#--------------------------------------------------
#      Chargement du fichier de configuration      
#--------------------------------------------------

if [ ! -r ${REP_PROG}/eaas_status.conf ]
then
  echo "===> ERREUR : le fichier de configuration ${REP_PROG}/eaas_status.conf est absent ou illisible"
  exit 1
fi
. ${REP_PROG}/eaas_status.conf

if ! command -v expect; then
echo -e "${ROUGE} Please install Expect !!${NORMAL} "
exit 1
fi

#--------------------------------------------------
#      Section de la creation de la Clef RSA      
#--------------------------------------------------

echo -e "${ROUGE}--------------------------------------------------------------${NORMAL}"
echo -e "${ROUGE}-----------------RSA.KEY CREATION-----------------------------${NORMAL}"
echo -e "${ROUGE}--------------------------------------------------------------${NORMAL}"

echo | ssh-keygen -P '' >/dev/null 2>&1
touch "${REP_RSA}/authorized_keys" 
chmod 0600 "${REP_RSA}/authorized_keys" 
cat "${REP_RSA}/id_rsa.pub" >> "${REP_RSA}/authorized_keys"

L_SERVERS=("${L_SERVEURS_ZOOKEEPER[@]}" "${L_SERVEURS_ASYNC[@]}" "${L_SERVEURS_RESTAPI[@]}" "${L_SERVEURS_SOLR_LEGA[@]}" "${L_SERVEURS_SOLR_CIBLE[@]}" "${L_SERVEURS_KAFKA[@]}" "${L_SERVEURS_KAFKA[@]}" "${L_SERVEURS_CASSANDRA[@]}")


#--------------------------------------------------
#      Section de la creation de la Clef RSA      
#--------------------------------------------------

for SERVER in ${L_SERVERS[@]}; do 
    if [ "${HOST}" != "${SERVER}" ] ; then 
        chmod a+x ./copy_rsa.exp && ./copy_rsa.exp $USER $PWD $SERVER "$REP_RSA"  | tee -a $REP_PROG/${USER}_rsadeployer_$LOG_DATE.log 1>&2
    fi
done

